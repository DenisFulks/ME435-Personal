function initializeDhAxes

    % Begin: Setup for this stand alone version that will NOT go into the GUI.
    close all
    app.axes_arm = axes;  % Create a new axes and save a handle to it.
    app.jointAngles = [0 -90 0 0 0 0 0]; % Start at the zero angle position.
    %  End : Setup for this stand alone version that will NOT go into the GUI.
    
    % Begin: Code that can go into your GUI's StartupFcn.
    clc
    
    % Prepare the axes_arm properties
    app.axes_arm.View = [90 -50];
    app.axes_arm.Visible = 'off';
    
    % Once you are in Matlab App Designer you can try these axes_arm properties too.
    % These properties keep the Axes from automatically resizing (optional)
    % app.axes_arm.XLim = [-200 1000];
    % app.axes_arm.YLim = [-200 200];
    % app.axes_arm.ZLim = [0 1000];
    
    % Create vertices for all the patches
    makeStlLink("LowL0.stl", app.axes_arm, [.2 .2 .2]);  % Doesn't move. No need to save a handle to it.
    % Save references to the vertices of each patch, make points 4x1 not 3x1.
    app.link1Patch = makeStlLink("LowL1.stl", app.axes_arm, [112/255 198/255 210/255]);
    app.link1Vertices = get(app.link1Patch, 'Vertices')';
    app.link1Vertices(4,:) = ones(1, size(app.link1Vertices,2));
    
    app.link2Patch = makeStlLink("LowL2.stl", app.axes_arm, [198/255 172/255 20/255]);
    app.link2Vertices = get(app.link2Patch, 'Vertices')';
    app.link2Vertices(4,:) = ones(1, size(app.link2Vertices,2));

    app.link3Patch = makeStlLink("LowL5.stl", app.axes_arm, [181/255 24/255 35/255]);
    app.link3Vertices = get(app.link3Patch, 'Vertices')';
    app.link3Vertices(4,:) = ones(1, size(app.link3Vertices,2));

    app.link4Patch = makeStlLink("LowL6.stl", app.axes_arm, [212/255 115/255 90/255]);
    app.link4Vertices = get(app.link4Patch, 'Vertices')';
    app.link4Vertices(4,:) = ones(1, size(app.link4Vertices,2));

    app.link5Patch = makeStlLink("LowL7.stl", app.axes_arm, [100/255 200/255 12/255]);
    app.link5Vertices = get(app.link5Patch, 'Vertices')';
    app.link5Vertices(4,:) = ones(1, size(app.link5Vertices,2));
    % End: Code that can go into your GUI's opening function.
    
    updateArm(app);

end

function updateArm(app)

    % Create the A homogeneous transformation matrices for the given jointAngles.
    A1 = create_A_matrix(50, 60, -90, app.jointAngles(1));
    A2 = create_A_matrix(100, 0, 0, app.jointAngles(2));
    A3 = create_A_matrix(0, 0, -90, app.jointAngles(3));
    A4 = create_A_matrix(0, 40, 90, app.jointAngles(4));
    A5 = create_A_matrix(0, 0, -90, app.jointAngles(5));

    % Use the current A matricies to form the T0_n matricies.
    T0_1 = A1;
    T0_2 = A1 * A2;
    T0_3 = A1 * A2 * A3;
    T0_4 = A1 * A2 * A3 * A4;
    T0_5 = A1 * A2 * A3 * A4 * A5;
    
    % Use the current T matricies to transform the original patch vertices
    link1VerticesWRTground = T0_1 * app.link1Vertices;
    link2VerticesWRTground = T0_2 * app.link2Vertices;
    link3VerticesWRTground = T0_3 * app.link3Vertices;
    link4VerticesWRTground = T0_4 * app.link4Vertices;
    link5VerticesWRTground = T0_5 * app.link5Vertices;
    
    % Update the patches with the newly transformed vertices
    set(app.link1Patch,'Vertices', link1VerticesWRTground(1:3,:)');
    set(app.link2Patch,'Vertices', link2VerticesWRTground(1:3,:)');
    set(app.link3Patch,'Vertices', link3VerticesWRTground(1:3,:)');
    set(app.link4Patch,'Vertices', link4VerticesWRTground(1:3,:)');
    set(app.link5Patch,'Vertices', link5VerticesWRTground(1:3,:)');

end
